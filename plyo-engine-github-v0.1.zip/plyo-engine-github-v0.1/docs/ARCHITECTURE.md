# Architecture v0.1

## Product framing

This engine is a low-tech, video-first plyometric measurement system. It is not a coaching product. It should prioritise accuracy, repeatability, validation and error reduction.

## Source of truth model

The core architecture should use:

```text
primary measurement source
+
validation layers
+
ML temporal correction
+
confidence/error model
```

Avoid making the raw measurement a vague weighted average. Weighting belongs primarily in confidence scoring and error estimation.

## Primary sources

- Video / pose landmarks: primary event and body-position source
- Audio: landing/contact validation and timing support
- Athlete reference: scaling, plausibility and force-related calculations
- ML: sub-frame temporal refinement

## Module boundaries

- `engine/ingestion`: file, metadata, frame and audio extraction
- `engine/athlete`: height, weight, sex/gender and anthropometric assumptions
- `engine/quality`: video/audio validity checks
- `engine/vision`: smart crop, MediaPipe integration, landmark cleaning, joint angles
- `engine/signals`: clean time-series generation
- `engine/audio`: impact detection and audio-video alignment
- `engine/events`: take-off, landing, contact, flight detection
- `engine/ml`: sub-frame timing correction
- `engine/metrics`: metric calculations
- `engine/confidence`: trust score, error estimates and flags
- `engine/validation`: manual label comparison and test reporting

## Analysis object

Every module receives and returns the same analysis object. This makes the pipeline debuggable and modular.
