# Plyo Engine Workbench v0.1

A GitHub Pages-ready scaffold for a video-first plyometric measurement engine.

The goal is not coaching or recommendations. The goal is to reduce measurement error from ordinary smartphone video using:

- video ingestion
- athlete reference inputs
- smart crop architecture
- MediaPipe-ready pose detection interface
- landmark cleaning
- signal extraction
- audio impact detection
- event detection
- ML temporal refinement placeholder
- metric extraction
- confidence and error estimation

## Run locally

Because the project uses ES modules, serve it from a local web server rather than opening `index.html` directly.

```bash
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Deploy to GitHub Pages

1. Create a new GitHub repository.
2. Upload all files in this folder to the repository root.
3. Go to **Settings → Pages**.
4. Set source to **Deploy from branch**.
5. Select branch: `main` and folder: `/root`.
6. Open the generated GitHub Pages URL.

## Current status

This is intentionally a scaffold. It proves the pipeline shape and keeps each future capability isolated.

The next major implementation step is MediaPipe integration in:

```text
engine/vision/poseDetector.js
```

## Architecture principle

The UI should never contain measurement logic.

```text
engine = measurement truth
ui = window into engine output
```

## Pipeline

```text
Video + Audio + Athlete Reference
↓
Ingestion
↓
Quality Gate
↓
Smart Crop
↓
MediaPipe Pose Extraction
↓
Landmark Cleaning
↓
Signal Extraction
↓
Audio Impact Detection
↓
Movement Event Detection
↓
ML Temporal Refinement
↓
Metric Extraction
↓
Confidence + Error Estimate
```
