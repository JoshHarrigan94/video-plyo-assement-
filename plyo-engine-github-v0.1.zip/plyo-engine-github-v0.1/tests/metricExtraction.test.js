import { jumpHeightFromFlightTime } from "../engine/metrics/jumpHeight.js";

const h = jumpHeightFromFlightTime(0.5);
console.assert(Math.abs(h - 0.306) < 0.01, "jumpHeightFromFlightTime should estimate ~0.306m for 0.5s flight time");
console.log("metricExtraction.test.js passed");
